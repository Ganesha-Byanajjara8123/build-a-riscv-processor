//tb_CPU_Top file
`timescale 1ns / 1ps

module tb_CPU_Top;

reg clk;
reg rst;

//CPU_Top module instantiation

CPU_Top dut (
.clk(clk),
.rst(rst)
);

//clk
 always #5 clk = ~clk;
 
always @(posedge clk) begin
    #1;   // Wait for register writes to complete

    $display("PC=%h Instr=%h", dut.PC_out, dut.Instruction_Out);

    $display("x1=%h x2=%h x3=%h x4=%h",
             dut.u_rf.my_regs[1],
             dut.u_rf.my_regs[2],
             dut.u_rf.my_regs[3],
             dut.u_rf.my_regs[4]);

    // Temporary debug signals (enable only when needed)
    $display("Added_data  = %h", dut.Added_data_out);
    $display("PC_plus4    = %h", dut.PC_plus4_out);
    $display("rd          = %0d", dut.Instruction_Out[11:7]);
    $display("WB_Data     = %h", dut.WB_Data_Out);
    $display("RegWr       = %b", dut.Reg_WrEn_Out);
    $display("NextPC      = %h", dut.Next_PC_Out);
    $display("BranchTaken = %b", dut.Branch_Taken_Out);

    $display("-----------------------------");
end
 
 initial begin
 //for waveforms
  $dumpfile("CPU_Top.vcd");
  $dumpvars(0, tb_CPU_Top);
  
rst = 1;
clk = 0;

#10;
rst = 0;

// Wait long enough for all instructions
repeat (8) @(posedge clk);

#1;

$display("\n========== FINAL REGISTER VALUES ==========");
$display("x1 = %h", dut.u_rf.my_regs[1]);
$display("x2 = %h", dut.u_rf.my_regs[2]);
$display("x3 = %h", dut.u_rf.my_regs[3]);
$display("x4 = %h", dut.u_rf.my_regs[4]);
$display("===========================================");

$finish;

end
endmodule


`timescale 1ns / 1ps

module CPU_Top(
    //decalreing external wires
    input         clk,
    input         rst
);

//decalreing internal wire of each Units

//PC_Unit.v wires
wire [31:0] PC_out;
wire	    Branch_Taken;
wire [31:0] Target_Address; 
wire [31:0] PC_plus4_out;

//PC_Src_MUX.v wires
wire [31:0] Next_PC_Out;

//Instruction_memory.v wire
wire [31:0] Instruction_Out;

//4)Decoder.v wires
wire 	   Reg_WrEn_Out;
wire [2:0] Imm_Type_Out;
wire 	   ladder_Src_Out;
wire       ALU_Src_Out;
wire [3:0] ALU_Control_Out;
wire       decoder_dm_wren;
wire [7:0] Branch_Cond_Out;
wire       Load_Unsigned_Out;
wire [1:0] Load_Size_Out;
wire [2:0] Result_Src_Out;

//register_file.v wires
wire [31:0] src_data1_out;
wire [31:0] src_data2_out;

//ALU_Src_MUX.v wire
wire [31:0] src2_out;

//ALU.v wire
wire [31:0] ALU_Result_out; 

//Branch_Comparator.v
wire Branch_Taken_Out;
wire Branch_Enable;

assign Branch_Enable = (Instruction_Out[6:0] == 7'b1100011);

//Extend_Unit.v wires
wire [31:0] Imm_out;

//Imm_adder.v wires
wire [31:0] Added_data_out;

//Store_Unit.v wires
wire [31:0] DM_Addr_Out;
wire [31:0] DM_WrData_Out;
wire [3:0]  DM_WrMask_Out;
wire        store_dm_wren;

//from WrBack MUX wire
wire [31:0]WB_Data_Out;

//Data_memory.v wire 
wire [31:0] Read_Data_Out;

//Load_Unit.v wires
wire [31:0] Loaded_Data_Out;

assign Branch_Taken   = Branch_Taken_Out;
assign Target_Address = Next_PC_Out;

//module instantiation

//PC_unit.v
PC_Unit u_pc (
.clk(clk),
.rst(rst),
.PC_out(PC_out),
.Branch_Taken(Branch_Taken),
.Target_Address(Target_Address),
.PC_plus4_out(PC_plus4_out)
);   

//PC_Src_MUX.v 
PC_Src_MUX u_PCsrcmux(
.PC_plus4_in(PC_plus4_out),
.Added_data_in(Added_data_out),
.PC_Sel(Branch_Taken_Out),
.Next_PC_Out(Next_PC_Out)
);

//Instruction_memory.v
Instruction_memory u_instrmem(
.PC_in(PC_out),
.Instruction_Out(Instruction_Out)
);


//Decoder.v
Decoder u_decoder (
.opcode_in(Instruction_Out[6:0]),
.funct3_in(Instruction_Out[14:12]),
.funct7_in(Instruction_Out[31:25]),
.Reg_WrEn_Out(Reg_WrEn_Out),
.Imm_Type_Out(Imm_Type_Out),
.ladder_Src_Out(ladder_Src_Out),
.ALU_Src_Out(ALU_Src_Out),
.ALU_Control_Out(ALU_Control_Out),
.DM_WrEn_Out(decoder_dm_wren),
.Branch_Cond_Out(Branch_Cond_Out),
.Load_Unsigned_Out(Load_Unsigned_Out),
.Load_Size_Out(Load_Size_Out),
.Result_Src_Out(Result_Src_Out)
);

//register_file.v
register_file u_rf(
.clk(clk),
.rst(rst),
.WrEn_in(Reg_WrEn_Out),
.des_addr_in(Instruction_Out[11:7]),
.des_data_in(WB_Data_Out),
.src_addr1_in(Instruction_Out[19:15]),
.src_addr2_in(Instruction_Out[24:20]),
.src_data1_out(src_data1_out),
.src_data2_out(src_data2_out)
);

//ALU_Src_MUX.v
ALU_Src_MUX u_alusrc(
.reg_data_in(src_data2_out),
.imm_data_in(Imm_out),
.ALU_Src_Sel(ALU_Src_Out),
.src2_out(src2_out )
);

//ALU 
ALU u_alu (
.src1_in(src_data1_out),
.src2_in(src2_out ),
.ALU_Control_in(ALU_Control_Out),
.ALU_Result_out(ALU_Result_out) 
);


//Branch_Comparator.v
Branch_Comparator u_BranchComp(
.RD1_in(src_data1_out),
.RD2_in(src_data2_out),
.Branch_Type_sel(Instruction_Out[14:12]),
.Branch_Enable(Branch_Enable),
.Branch_Taken_Out(Branch_Taken_Out)
);

//Extend_Unit.v
Extend_Unit u_ext(
.instr_in(Instruction_Out),
.Imm_type_in(Imm_Type_Out),
.Imm_out(Imm_out)
);

//Imm_adder.v
Imm_Adder u_immadd (
.ladder_src_in(ladder_Src_Out),
.PC_in(PC_out),
.Src_Data1_in(src_data1_out), //by MUX
.imm_Data_in(Imm_out),
.Added_data_out(Added_data_out)
);

// Store_Unit.v 
 Store_Unit u_store (
.DM_WrEn_In(decoder_dm_wren),
.Func3_In(Instruction_Out[14:12]),
.Added_Data_In(Added_data_out),
.Src_Data2_In(src_data2_out),
.DM_Addr_Out(DM_Addr_Out),
.DM_WrData_Out(DM_WrData_Out),
.DM_WrMask_Out(DM_WrMask_Out),
.DM_WrEn_Out(store_dm_wren)     
 );
 
//WB_MUX.v
WB_MUX u_WBmux(
.ALU_Result_in(ALU_Result_out),
.Loaded_data_in(Loaded_Data_Out),
.PC_plus4_in(PC_plus4_out),
.Imm_in(Imm_out),
.Result_Src_in(Result_Src_Out),
.WB_Data_Out(WB_Data_Out)
); 
 
 //Data_memory.v
 Data_Memory u_DM(
 .clk(clk),
 .DM_Addr_in(DM_Addr_Out),
 .DM_WrData_in(DM_WrData_Out),
 .DM_WrMask_in(DM_WrMask_Out),
 .DM_WrEn_in(store_dm_wren),
 .Read_Data_Out(Read_Data_Out)
 );
 
 //Load_Unit.v
 Load_Unit u_load(
 .Read_Data_In(Read_Data_Out),
 .Load_Size_In(Load_Size_Out),
 .Load_Unsigned_In(Load_Unsigned_Out),
 .Loaded_Data_Out(Loaded_Data_Out)
 );
 
 endmodule

 
 
module Decoder(
    input  [6:0] opcode_in,
    input  [2:0] funct3_in,
    input  [6:0] funct7_in,

    output reg       Reg_WrEn_Out,
    output reg [2:0] Imm_Type_Out,
    output reg       ladder_Src_Out,
    output reg       ALU_Src_Out,
    output reg [3:0] ALU_Control_Out,
    output reg       DM_WrEn_Out,
    output reg [7:0] Branch_Cond_Out,
    output reg       Load_Unsigned_Out,
    output reg [1:0] Load_Size_Out,
    output reg [2:0] Result_Src_Out
);

always @(*) begin

    // Default values
    Reg_WrEn_Out      = 1'b0;
    Imm_Type_Out      = 3'b000;
    ladder_Src_Out    = 1'b0;
    ALU_Src_Out       = 1'b0;
    ALU_Control_Out   = 4'b0000;
    DM_WrEn_Out       = 1'b0;
    Branch_Cond_Out   = 8'b00000000;
    Load_Unsigned_Out = 1'b0;
    Load_Size_Out     = 2'b00;
    Result_Src_Out    = 3'b000;

    case(opcode_in)

    // R-Type
    7'b0110011: begin

        Reg_WrEn_Out = 1'b1;
        ALU_Src_Out  = 1'b0;

        case({funct7_in,funct3_in})

             //10bits = funct3 + funct7
            10'b0000000_000: ALU_Control_Out = 4'b0000; // ADD & about 10bits funct3=000 funct7=0000000 = 10'b0000000_000
            10'b0100000_000: ALU_Control_Out = 4'b0001; // SUB & about 10bits funct3=000 funct7=0100000 = 10'b0100000_000 (same for remaining cases)
            10'b0000000_111: ALU_Control_Out = 4'b0010; // AND
            10'b0000000_110: ALU_Control_Out = 4'b0011; // OR
            10'b0000000_100: ALU_Control_Out = 4'b0100; // XOR
            10'b0000000_001: ALU_Control_Out = 4'b0101; // SLL
            10'b0000000_101: ALU_Control_Out = 4'b0110; // SRL
            10'b0100000_101: ALU_Control_Out = 4'b0111; // SRA
            10'b0000000_010: ALU_Control_Out = 4'b1000; // SLT
            10'b0000000_011: ALU_Control_Out = 4'b1001; // SLTU

            default: ALU_Control_Out = 4'b0000;

        endcase
    end

    // I-Type ALU
    7'b0010011: begin
        Reg_WrEn_Out = 1'b1;
        ALU_Src_Out  = 1'b1;
        Imm_Type_Out = 3'b000;
		
		case(funct3_in)
		
		3'b000: ALU_Control_Out = 4'b0000; // ADDI
		3'b111: ALU_Control_Out = 4'b0010; // ANDI
		3'b110: ALU_Control_Out = 4'b0011; // ORI
		3'b100: ALU_Control_Out = 4'b0100; // XORI
		3'b001: ALU_Control_Out = 4'b0101; // SLLI
		
		3'b101: begin
		    if(funct7_in == 7'b0000000)
			   ALU_Control_Out = 4'b0110; // SRLI
			else if(funct7_in == 7'b0100000)
			    ALU_Control_Out = 4'b0111; // SRAI
				
		end
		
		3'b010: ALU_Control_Out = 4'b1000; // SLTI
		3'b011: ALU_Control_Out = 4'b1001; // SLTU
		endcase
	
    end


    // STORE
    7'b0100011: begin
        DM_WrEn_Out    = 1'b1;
        ALU_Src_Out    = 1'b1;
        Imm_Type_Out   = 3'b001;   // S-Type
        ALU_Control_Out = 4'b0000; // Always ADD
	
    end
    //LOAD
    7'b0000011: begin
    Reg_WrEn_Out    = 1'b1;      // Write loaded data to register
    DM_WrEn_Out     = 1'b0;      // Do NOT write memory
    ALU_Src_Out     = 1'b1;
    Imm_Type_Out    = 3'b000;    // I-Type immediate
    ALU_Control_Out = 4'b0000;   // Address = rs1 + imm
    Result_Src_Out  = 3'b001;    // Select Data Memory output
	
    end	

    // BRANCH
    7'b1100011: begin
    Imm_Type_Out    = 3'b010;
    Branch_Cond_Out = 8'b00000001;
    ladder_Src_Out  = 1'b1;    
		
		case(funct3_in)

        3'b000 : ALU_Control_Out = 4'b0000; //BEQ
        3'b001 : ALU_Control_Out = 4'b0101; //BNE
        3'b100 : ALU_Control_Out = 4'b0100; //BLT
        3'b101 : ALU_Control_Out = 4'b0110; //BGE
        3'b110 : ALU_Control_Out = 4'b0011; //BLTU
        3'b111 : ALU_Control_Out = 4'b0010; //BGEU
		
		default: ALU_Control_Out = 4'b0000;

endcase
    end

    // JAL
    7'b1101111: begin
        Reg_WrEn_Out   = 1'b1;
        Imm_Type_Out   = 3'b100;
        Result_Src_Out = 3'b010;
    end

    // JALR
    7'b1100111: begin
        Reg_WrEn_Out   = 1'b1;
        Imm_Type_Out   = 3'b001;
        Result_Src_Out = 3'b010;
    end

    // LUI
    7'b0110111: begin
        Reg_WrEn_Out = 1'b1;
        Imm_Type_Out = 3'b101;
    end

    // AUIPC
    7'b0010111: begin
        Reg_WrEn_Out   = 1'b1;
        Imm_Type_Out   = 3'b101;
        ladder_Src_Out = 1'b1;
    end

    default: begin
    end

    endcase

end

endmodule
 




`timescale 1ns / 1ps

module Branch_Comparator(
input[31:0] RD1_in,           // (Register value 1)
input[31:0] RD2_in,           //(Register value 2)
input[2:0]  Branch_Type_sel,  //funct3-Decoder
input       Branch_Enable,
output reg  Branch_Taken_Out // go to PC_Src_MUX
);

always@(*)begin

Branch_Taken_Out = 1'b0;


if(Branch_Enable) begin

    case(Branch_Type_sel)

3'b000: Branch_Taken_Out = (RD1_in == RD2_in);                    //BEQ-Branch if Equal
3'b001: Branch_Taken_Out = (RD1_in != RD2_in);                    //BNE-Branch if Not Equal
3'b100: Branch_Taken_Out = ($signed(RD1_in) < $signed(RD2_in));   //BLT-Branch if Less Than (signed)
3'b101: Branch_Taken_Out = ($signed(RD1_in) >=  $signed(RD2_in)); //BGE-Branch if Greater or Equal (signed)
3'b110: Branch_Taken_Out = (RD1_in < RD2_in);                     // BLTU-Branch if Less Than (unsigned)
3'b111: Branch_Taken_Out = (RD1_in >= RD2_in);                    //BGEU-Branch if Greater or Equal (unsigned) 

default : Branch_Taken_Out = 1'b0;                              //for default case
endcase
end
end
endmodule

