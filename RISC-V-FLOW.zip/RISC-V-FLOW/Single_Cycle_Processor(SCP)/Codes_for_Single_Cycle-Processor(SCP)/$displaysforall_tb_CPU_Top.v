1. Permanent always @(posedge clk) block
always @(posedge clk) begin
    #1;    // Wait for register write

    $display("--------------------------------------------------");
    $display("PC=%h  Instr=%h", dut.PC_out, dut.Instruction_Out);

    $display("x1=%h  x2=%h  x3=%h  x4=%h  x5=%h",
             dut.u_rf.my_regs[1],
             dut.u_rf.my_regs[2],
             dut.u_rf.my_regs[3],
             dut.u_rf.my_regs[4],
             dut.u_rf.my_regs[5]);
end

This is enough to verify almost every instruction.

2. Permanent initial block
initial begin

    rst = 1;
    clk = 0;

    #10;
    rst = 0;

    repeat(10) @(posedge clk);

    #1;

    $display("\n========== FINAL REGISTER VALUES ==========");
    $display("x1 = %h", dut.u_rf.my_regs[1]);
    $display("x2 = %h", dut.u_rf.my_regs[2]);
    $display("x3 = %h", dut.u_rf.my_regs[3]);
    $display("x4 = %h", dut.u_rf.my_regs[4]);
    $display("x5 = %h", dut.u_rf.my_regs[5]);
    $display("===========================================\n");

    $finish;
end

I would keep this permanently throughout the project.

Temporary Debug Displays

Enable these only when debugging a specific block.

ALU Debug
$display("ALUCtrl    = %b", dut.ALU_Control_Out);
$display("src1       = %h", dut.src_data1_out);
$display("src2       = %h", dut.src2_out);
$display("ALU_Result = %h", dut.ALU_Result_out);

Use for:

R-Type
I-Type
ALU bugs
Immediate Generator Debug
$display("ImmType = %b", dut.Imm_Type_Out);
$display("Imm_out = %h", dut.Imm_out);

Use for:

I-Type
Store
Load
Branch
LUI
AUIPC
JAL
JALR

Register Write Debug
$display("RegWr   = %b", dut.Reg_WrEn_Out);
$display("rd      = %0d", dut.Instruction_Out[11:7]);
$display("WB_Data = %h", dut.WB_Data_Out);

Use when the register file isn't updating correctly.

Branch Debug
$display("BranchTaken = %b", dut.Branch_Taken_Out);
$display("NextPC      = %h", dut.Next_PC_Out);
$display("Added_data  = %h", dut.Added_data_out);
$display("PC_plus4    = %h", dut.PC_plus4_out);

Use only for:

BEQ
BNE
BLT
BGE
BLTU
BGEU
JAL
JALR

Store Debug
$display("Addr      = %h", dut.DM_Addr_Out);
$display("WrData    = %h", dut.DM_WrData_Out);
$display("WrMask    = %b", dut.DM_WrMask_Out);
$display("DM_WrEn   = %b", dut.store_dm_wren);

Load Debug
$display("ReadData   = %h", dut.Read_Data_Out);
$display("LoadedData = %h", dut.Loaded_Data_Out);

Instruction Decode Debug
$display("opcode    = %b", dut.Instruction_Out[6:0]);
$display("funct3    = %b", dut.Instruction_Out[14:12]);
$display("funct7    = %b", dut.Instruction_Out[31:25]);

