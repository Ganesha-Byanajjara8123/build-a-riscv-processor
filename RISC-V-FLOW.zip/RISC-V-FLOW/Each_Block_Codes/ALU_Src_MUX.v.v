//code for ALU_Src_MUX.v    



















/* notes

	Register File (RD2)
                        │
                        │
                        ▼
                  ┌──────────┐
Immediate ───────►│          │
                  │   MUX    │──────► ALU src2
ALU_Src ─────────►│          │
                  └──────────┘