
//tb_CPU_Top file
`timescale 1ns / 1ps

module tb_CPU_Top;

reg clk;
reg rst;

//CPU_Top module instantiation

CPU_Top dut (
.clk(clk),
.rst(rst)
);

//clk
 always #5 clk = ~clk;
 
 always @(posedge clk) begin
    #1;    // Wait for register write

    $display("--------------------------------------------------");
    $display("PC=%h  Instr=%h", dut.PC_out, dut.Instruction_Out);

    $display("x1=%h x2=%h x3=%h  x4=%h  x5=%h",
             dut.u_rf.my_regs[1],
             dut.u_rf.my_regs[2],
             dut.u_rf.my_regs[3],
             dut.u_rf.my_regs[4],
             dut.u_rf.my_regs[5]);
					 
end

   
 
 initial begin

    rst = 1;
    clk = 0;

    #10;
    rst = 0;

    repeat(10) @(posedge clk);

    #1;

    $display("\n========== FINAL REGISTER VALUES ==========");
    $display("x1 = %h", dut.u_rf.my_regs[1]);
    $display("x2 = %h", dut.u_rf.my_regs[2]);
    $display("x3 = %h", dut.u_rf.my_regs[3]);
    $display("x4 = %h", dut.u_rf.my_regs[4]);
    $display("x5 = %h", dut.u_rf.my_regs[5]);
    $display("===========================================\n");

    $finish;

end
endmodule
  
  
/*
cp ~/verilator_lab/program.hex ~/verilator_lab/obj_dir/program.hex
cd ~/verilator_lab/obj_dir
./Vtb_CPU_Top

we have to verify all these to complete single cycle processor.
R-Type ALU
-----------
□ AND
□ OR
□ XOR
□ SLL
□ SRL
□ SRA
□ SLT
□ SLTU

I-Type ALU
----------
□ ANDI
□ ORI
□ XORI
□ SLLI
□ SRLI
□ SRAI
□ SLTI
□ SLTIU

Memory
------
□ SB
□ SH
□ SW
□ LB
□ LH
□ LW
□ LBU
□ LHU

Branch
------
□ BEQ
□ BNE
□ BLT
□ BGE
□ BLTU
□ BGEU

Jump
----
□ JAL
□ JALR

Upper Immediate
---------------
□ LUI
□ AUIPC

*/  
  
/*R-Type Instruction Format

Every R-type instruction has this format:
31          25 24    20 19    15 14   12 11     7 6      0

 funct7        rs2      rs1     funct3    rd      opcode
 
 Let's divide our instruction.
 
 0000000 00010 00001 000 00011 0110011 - this is our RISC instructions
 
 now every lable has:
 
 0000000 | 00010 | 00001 | 000 | 00011 | 0110011
 funct7 |  rs2  |  rs1  |f3   |   rd  | opcode
 
 
 //after all instantiation of modules then we verified it like by just created one program.hex file,
 only one instruction such as 00A00093 --> addi x1, x0, 10
 for Addi:
Read x0
Use Immediate(10)
Perform ADD
Write result back
after this we proved which is:

Instruction Memory
        ↓
Instruction Fetch
        ↓
Decoder
        ↓
Control Signals

then next we move to :
Instruction
      ↓
Extend_Unit
      ↓
Immediate

for addi x1,x0,10


Remaining roadmap
✅ PC
✅ Instruction Memory
✅ Decoder
✅ Register File
✅ Extend Unit
✅ ALU
✅ WB MUX
✅ ADDI
✅ ADD

-------------------------
NEXT

1. R-Type ALU Instructions
   □ SUB
   □ AND
   □ OR
   □ XOR
   □ SLL
   □ SRL
   □ SRA
   □ SLT
   □ SLTU

2. I-Type ALU Instructions
   □ ANDI
   □ ORI
   □ XORI
   □ SLTI
   □ SLLI
   □ SRLI
   □ SRAI

3. Store Instructions
   □ SB
   □ SH
   □ SW

4. Load Instructions
   □ LB
   □ LH
   □ LW
   □ LBU
   □ LHU

5. Branch Instructions
   □ BEQ
   □ BNE
   □ BLT
   □ BGE
   □ BLTU
   □ BGEU

6. Jump Instructions
   □ JAL
   □ JALR

7. U-Type
   □ LUI
   □ AUIPC
   
##how to build machine code which is going to Instruction file as like program.hex
Step 1: Recall the RISC-V R-type format

For an R-type instruction (add, sub, and, or, ...), the format is:

31        25 24   20 19   15 14  12 11    7 6      0
+-----------+-------+-------+------+-------+--------+
| funct7    | rs2   | rs1   |funct3|  rd   | opcode |
+-----------+-------+-------+------+-------+--------+
Step 2: Take this instruction
sub x3, x1, x2

Now fill the fields.

opcode

All R-type ALU instructions use:

0110011
rd

Destination is:

x3

Register number?

You tell me.

(Hint: write it in 5-bit binary.)

rs1

Source-1:

x1

Again, convert to 5-bit binary.

rs2

Source-2:

x2

Convert to 5-bit binary.

funct3

For SUB,

What is funct3?

(Hint: it's the same as ADD.)

funct7

This is what distinguishes ADD from SUB.

For SUB:

0100000
Step 3

Now arrange them:

funct7
rs2
rs1
funct3
rd
opcode

into one 32-bit number.

I want you to fill this table
Field	Value
funct7	?
rs2	?
rs1	?
funct3	?
rd	?
opcode	?

Once you fill those six values, we'll concatenate them into binary, convert to hexadecimal, and
 finally split them into the four bytes that go into program.hex.   
 
 
 Field	Correct Value
funct7	0100000 ✅
rs2	00010
rs1	00001
funct3	000 ✅
rd	00011
opcode	0110011

then conver it into 32-bit which is = 32'b01000000001000001000000110110011 Now convert it to hexadecimal = 0x402081B3
Split it into 8-bit chunks:

40   20   81   B3

These are the bytes from MSB → LSB.
Step 2: Store in little-endian order

RISC-V is little-endian.
That means the least significant byte goes to the lowest address.
So in program.hex you write:
B3
81
20
40

For I-Type:
ADDI   (already done)
ANDI
ORI
XORI
SLLI
SRLI
SRAI
SLTI
SLTIU


R-Type / I-Type
ALUCtrl
Imm_out
ALU_Result

Store:
DM_Addr
DM_WrData
memory[address]

Load:
Read_Data
Loaded_Data
WB_Data

Branch:
BranchTaken
Added_data
NextPC