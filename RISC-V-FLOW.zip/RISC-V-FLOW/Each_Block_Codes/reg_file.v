/* key-notes
write prots : CPU stores the data into regs
if wrEn=1 data will be stored in regs or wrEn=0 data will not stored in regs
destination addr: This selects WHICH register to write.
write data: 32-bit data entering the regfile
*/


module register_file(
input        clk,                    //Global ports
input        rst,
input        WrEn_in,                //write ports
input [4:0]  des_addr_in,
input [31:0] des_data_in, 
input [4:0]  src_addr1_in,          //Read ports  
input [4:0]  src_addr2_in,

output [31:0] src_data1_out,
output [31:0] src_data2_out

);

reg[31:0] my_regs[0:31];   //32-regs and each have 32-bits

integer i;

always@(posedge clk or posedge rst) begin
if(rst) begin
for(i = 0; i < 32; i = i + 1)
my_regs[i] = 32'b0;
end

    else if (WrEn_in) begin
    if(des_addr_in != 5'b00000)
    my_regs[des_addr_in] <= des_data_in;
end
end

assign src_data1_out = my_regs[src_addr1_in];  //go to register selected by address return stored value
assign src_data2_out = my_regs[src_addr2_in];

endmodule 


